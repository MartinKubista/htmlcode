<!DOCTYPE html>
<html lnag="en">
<head>
    <link href="../css/search-bar.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/fonts.css">  
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
</head>

<div class="main-div-search-bar">
    <form class="search-bar" method="get">
        <input class = "search" type="text" placeholder="Začnite vyhľadávať" name="keyword">
        <div class="find-button">
        <button action="submit" class="material-symbols-outlined" name="search">search</button>
        </div>
    </form>
</div>

